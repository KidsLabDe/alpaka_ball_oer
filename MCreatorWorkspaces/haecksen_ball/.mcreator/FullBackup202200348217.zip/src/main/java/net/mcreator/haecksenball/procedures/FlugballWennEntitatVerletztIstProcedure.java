package net.mcreator.haecksenball.procedures;

public class FlugballWennEntitatVerletztIstProcedure {
	public static void execute() {
	}
}
